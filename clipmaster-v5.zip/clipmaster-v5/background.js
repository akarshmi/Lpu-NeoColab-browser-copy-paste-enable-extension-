/*
 * background.js
 *
 * ROOT CAUSE OF THE CRASH:
 * chrome.tabs.sendMessage() throws an uncaught error when the receiving
 * content script isn't ready yet (e.g. page just loaded, chrome:// pages,
 * PDFs, extension pages). In MV3 a single uncaught throw kills the entire
 * service worker — that's the "background.js:0 anonymous" error you saw.
 *
 * FIX: Use chrome.scripting.executeScript() instead.
 * It injects a tiny function directly into the tab's MAIN world,
 * firing the CustomEvent that injector.js already listens for.
 * It never crashes — errors are caught and silently ignored.
 */
chrome.action.onClicked.addListener(async (tab) => {
  // Can't inject into browser-internal pages
  if (!tab || !tab.url) return;
  if (/^(chrome|edge|about|data):/.test(tab.url)) return;

  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: "MAIN",          // same world as injector.js — event is heard
      func: () => window.dispatchEvent(new CustomEvent("__cm_toggle"))
    });
  } catch (_) {
    // tab was closed, navigating, or is a protected page — ignore
  }
});
