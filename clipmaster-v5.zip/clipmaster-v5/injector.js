(() => {
  if (window.__cmLoaded) return;
  window.__cmLoaded = true;

  /* ════════════════════════════════════════════════
     PASTE STATE  (your original two variables)
  ════════════════════════════════════════════════ */
  let selectedEditor = null;
  let enabled        = true;

  /* ════════════════════════════════════════════════
     SCROLLER STATE  (your scroller variables)
  ════════════════════════════════════════════════ */
  let scrollRunning = false;
  let scrollTimeout = null;
  // configurable — user can tweak in the panel
  let cfg = {
    minPause:    1200,
    maxPause:    2500,
    minDistance: 120,
    maxDistance: 260,
    smoothTime:  650
  };

  /* ════════════════════════════════════════════════
     STYLES
  ════════════════════════════════════════════════ */
  const css = document.createElement("style");
  css.textContent = `
    @import url('https://fonts.googleapis.com/css2?family=Fredoka+One&family=Nunito:wght@700;800;900&display=swap');

    #cm-root {
      position: fixed;
      top: 14px; right: 14px;
      z-index: 2147483647;
      display: flex;
      flex-direction: column;
      align-items: flex-end;
    }

    /* ─ drag handle ─ */
    #cm-drag {
      width: 100%; height: 18px;
      background: rgba(20,4,44,0.75);
      border-radius: 14px 14px 0 0;
      display: flex; align-items: center; justify-content: center;
      cursor: grab; gap: 5px;
      backdrop-filter: blur(8px);
    }
    #cm-drag:active { cursor: grabbing; }
    #cm-drag i {
      width: 4px; height: 4px; border-radius: 50%;
      background: #3a1055; display: block;
      transition: background .15s;
    }
    #cm-drag:hover i { background: #ff6aff; }

    /* ─ panel ─ */
    #cm-panel {
      width: 220px;
      background: rgba(14,2,30,0.84);
      backdrop-filter: blur(16px);
      -webkit-backdrop-filter: blur(16px);
      border: 1.5px solid rgba(204,0,255,0.45);
      border-top: none;
      border-radius: 0 0 14px 14px;
      overflow: hidden;
      box-shadow: 0 0 0 3px rgba(204,0,255,.07), 0 20px 50px rgba(0,0,0,.6);
    }

    /* ─ header ─ */
    #cm-head {
      display: flex; align-items: center; gap: 7px;
      padding: 8px 10px 7px;
      background: rgba(28,4,56,0.62);
      border-bottom: 1px solid rgba(90,0,130,0.4);
    }
    #cm-title {
      font-family: 'Fredoka One', 'Comic Sans MS', cursive;
      font-size: 12px;
      color: rgba(255,106,255,0.6);
      flex: none;
    }
    #cm-author {
      font-family: 'Fredoka One', 'Comic Sans MS', cursive;
      font-size: 15px; color: #ff6aff;
      text-decoration: none; flex: 1;
      text-shadow: 0 0 10px rgba(255,106,255,.5);
      white-space: nowrap;
      transition: color .15s;
    }
    #cm-author:hover { color: #fff; text-shadow: 0 0 18px rgba(255,106,255,.9); }

    /* ─ two round control buttons ─ */
    .cm-ctrl {
      width: 20px; height: 20px;
      border-radius: 50%; border: none;
      cursor: pointer; flex-shrink: 0;
      position: relative;
      transition: transform .15s, box-shadow .15s;
    }
    .cm-ctrl::after {           /* shine dot */
      content: ''; width: 5px; height: 5px;
      border-radius: 50%;
      background: rgba(255,255,255,.38);
      position: absolute; top: 3px; left: 5px;
    }
    .cm-ctrl:hover  { transform: scale(1.18); }
    .cm-ctrl:active { transform: scale(.9); }

    /* purple ball → shrink to orb */
    #cm-ball-btn {
      background: radial-gradient(circle at 35% 30%, #ffffff, #ffffff);
      box-shadow: 0 0 8px rgba(255, 255, 255, 0.5);
    }
    #cm-ball-btn:hover { box-shadow: 0 0 18px rgba(255, 255, 255, 0.9); }

    /* WHITE ball → vanish (blends with light pages) */
    #cm-vanish-btn {
      background: radial-gradient(circle at 35% 30%, #ffffff, #d0d0d0);
      box-shadow: 0 0 6px rgba(255,255,255,.5), 0 0 0 1.5px rgba(180,180,180,.4);
    }
    #cm-vanish-btn:hover { box-shadow: 0 0 14px rgba(255,255,255,.9); }

    /* ─ tab bar ─ */
    #cm-tabs {
      display: flex;
      border-bottom: 1px solid rgba(90,0,130,0.35);
      background: rgba(18,0,38,0.5);
    }
    .cm-tab {
      flex: 1; padding: 6px 0;
      background: transparent; border: none;
      font-family: 'Fredoka One', cursive;
      font-size: 11px; color: #5a2a7a;
      cursor: pointer; letter-spacing: .04em;
      transition: color .15s, background .15s;
      border-bottom: 2px solid transparent;
    }
    .cm-tab:hover { color: #cc88ff; }
    .cm-tab.active {
      color: #ff6aff;
      border-bottom-color: #cc00ff;
      background: rgba(80,0,120,.15);
    }

    /* ─ tab panes ─ */
    .cm-pane { display: none; }
    .cm-pane.active { display: block; }

    /* ─ status bar ─ */
    #cm-status {
      display: flex; align-items: center; gap: 8px;
      padding: 5px 12px;
      background: rgba(8,0,20,0.5);
      border-bottom: 1px solid rgba(30,0,64,0.5);
    }
    #cm-led {
      width: 7px; height: 7px; border-radius: 50%;
      flex-shrink: 0; background: #2a0050;
      transition: background .3s;
    }
    #cm-led.ready  { background:#cc00ff; animation:cmGlow  1.8s infinite; }
    #cm-led.active { background:#00ffaa; animation:cmGlow2 1.8s infinite; }
    #cm-led.off    { background:#ff3355; box-shadow:0 0 6px #ff3355; }
    @keyframes cmGlow  { 0%,100%{box-shadow:0 0 4px #cc00ff} 50%{box-shadow:0 0 14px #cc00ff} }
    @keyframes cmGlow2 { 0%,100%{box-shadow:0 0 4px #00ffaa} 50%{box-shadow:0 0 14px #00ffaa} }
    #cm-msg {
      font-family:'Nunito','Comic Sans MS',cursive;
      font-size:10px; font-weight:700; color:#5a2a7a;
      flex:1; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;
    }

    /* ─ action buttons ─ */
    #cm-btns {
      padding: 6px 6px 7px;
      display: flex; flex-direction: column; gap: 3px;
      background: rgba(10,0,26,0.5);
    }
    .cm-btn {
      display:flex; align-items:center; gap:9px;
      width:100%; padding:7px 10px;
      background:rgba(24,0,48,0.55);
      border:1.5px solid rgba(46,0,85,0.7);
      border-radius:9px; cursor:pointer;
      font-family:'Nunito','Comic Sans MS',cursive;
      font-size:12px; font-weight:800; color:#7744aa;
      text-align:left; transition:all .13s;
    }
    .cm-btn:hover {
      transform:translateX(3px) scale(1.01);
      border-color:rgba(204,0,255,.7); color:#ff9aff;
      background:rgba(34,0,68,.7);
      box-shadow:0 0 10px rgba(204,0,255,.18);
    }
    .cm-btn:active { transform:scale(.97); }
    .cm-icon { width:22px;height:22px;border-radius:6px;display:flex;align-items:center;justify-content:center;font-size:14px;flex-shrink:0; }
    #cm-btn-select:hover { border-color:rgba(255,215,0,.7); color:#ffd700; }
    #cm-btn-paste:hover  { border-color:rgba(0,255,200,.7);  color:#00ffcc; }
    #cm-btn-clear:hover  { border-color:rgba(255,60,120,.7);  color:#ff3c78; }
    #cm-btn-toggle:hover { border-color:rgba(255,106,255,.7); color:#ff6aff; }
    .cm-kbd {
      margin-left:auto; background:rgba(10,0,24,.6);
      border:1px solid rgba(42,0,80,.8); border-radius:5px;
      padding:1px 6px; font-family:'Nunito',cursive;
      font-size:9px; font-weight:900; color:#3a1060;
    }
    .cm-sep { height:1px; background:linear-gradient(90deg,transparent,rgba(60,0,100,.5),transparent); margin:2px 4px; }

    /* ─ SCROLLER PANEL ─ */
    #cm-scroll-pane {
      padding: 8px 8px 10px;
      background: rgba(10,0,26,0.5);
      display: flex; flex-direction: column; gap: 6px;
    }

    /* big start/stop button */
    #cm-scroll-toggle {
      width: 100%; padding: 9px;
      border-radius: 10px; border: none; cursor: pointer;
      font-family: 'Fredoka One', cursive;
      font-size: 14px; letter-spacing: .05em;
      transition: all .15s;
      background: rgba(0,200,100,.12);
      border: 1.5px solid rgba(0,200,100,.4);
      color: #00cc66;
    }
    #cm-scroll-toggle:hover {
      background: rgba(0,200,100,.22);
      box-shadow: 0 0 12px rgba(0,200,100,.3);
    }
    #cm-scroll-toggle.running {
      background: rgba(255,60,80,.12);
      border-color: rgba(255,60,80,.4);
      color: #ff3c50;
    }
    #cm-scroll-toggle.running:hover {
      background: rgba(255,60,80,.22);
      box-shadow: 0 0 12px rgba(255,60,80,.3);
    }

    /* slider rows */
    .cm-slider-row {
      display: flex; flex-direction: column; gap: 2px;
    }
    .cm-slider-label {
      display: flex; justify-content: space-between;
      font-family: 'Nunito', cursive;
      font-size: 10px; font-weight: 700; color: #5a2a7a;
    }
    .cm-slider-label span { color: #aa66cc; font-weight: 900; }
    input[type=range] {
      width: 100%; height: 4px;
      accent-color: #cc00ff;
      cursor: pointer; border-radius: 4px;
    }

    /* scroll status indicator */
    #cm-scroll-status {
      text-align: center;
      font-family: 'Nunito', cursive;
      font-size: 10px; font-weight: 700;
      color: #3a1060; letter-spacing: .04em;
      padding: 2px 0;
    }
    #cm-scroll-status.on  { color: #00cc66; }
    #cm-scroll-status.off { color: #3a1060; }

    /* ─ toast ─ */
    #cm-toast {
      position:fixed; bottom:16px; right:16px;
      z-index:2147483647;
      font-family:'Nunito','Comic Sans MS',cursive;
      font-size:13px; font-weight:800;
      padding:9px 16px; border-radius:12px;
      pointer-events:none; opacity:0;
      transform:translateY(10px) scale(.96);
      transition:opacity .18s,transform .18s;
      max-width:calc(100vw - 32px);
    }
    #cm-toast.show { opacity:1; transform:translateY(0) scale(1); }
    #cm-toast.ok   { background:#001a10; border:2px solid #00ffaa; color:#00ffaa; box-shadow:0 0 18px rgba(0,255,170,.3); }
    #cm-toast.err  { background:#1a0008; border:2px solid #ff3c78; color:#ff3c78; box-shadow:0 0 18px rgba(255,60,120,.3); }
    #cm-toast.info { background:rgba(10,0,26,.92); border:2px solid rgba(204,0,255,.6); color:#dd88ff; }

    /* ─ glowing ORB (minimised) ─ */
    #cm-orb {
      display: none;
      width: 38px; height: 38px; border-radius: 50%;
      background: radial-gradient(circle at 35% 30%, #ffffff, #ffffff);
      box-shadow: 0 0 12px rgba(255, 255, 255, 0.6), 0 0 28px rgba(255, 255, 255, 0.22),
                  inset 0 2px 4px rgba(255,255,255,.18);
      cursor: pointer; position: relative;
      transition: box-shadow .2s, transform .15s;
    }
    #cm-orb:hover { transform:scale(1.12); box-shadow:0 0 22px rgba(204,0,255,.9),0 0 44px rgba(204,0,255,.3); }
    #cm-orb::before { content:''; position:absolute; width:10px;height:10px; background:rgba(255,255,255,.32); border-radius:50%; top:6px;left:8px; }
    #cm-orb::after  { content:''; position:absolute; inset:-5px; border-radius:50%; border:2px solid rgba(204,0,255,.28); animation:cmRing 2s infinite; }
    @keyframes cmRing { 0%{transform:scale(1);opacity:.6} 100%{transform:scale(1.35);opacity:0} }
  `;
  document.head.appendChild(css);

  /* ════════════════════════════════════════════════
     DOM
  ════════════════════════════════════════════════ */
  const root = document.createElement("div");
  root.id = "cm-root";
  root.innerHTML = `
    <!-- Glowing orb (minimised state) -->
    <div id="cm-orb" title="Click to expand"></div>

    <!-- Drag handle -->
    <div id="cm-drag"><i></i><i></i><i></i><i></i><i></i><i></i></div>

    <!-- Main panel -->
    <div id="cm-panel">

      <!-- Header -->
      <div id="cm-head">
        <span id="cm-title">📋</span>
        <a id="cm-author" href="https://github.com/akarshmi"
           target="_blank" rel="noopener">@akarshmi</a>
        <button id="cm-ball-btn"   class="cm-ctrl" title="Minimise to ball"></button>
        <button id="cm-vanish-btn" class="cm-ctrl" title="Vanish — click extension icon to restore"></button>
      </div>

      <!-- Tabs -->
      <div id="cm-tabs">
        <button class="cm-tab active" data-tab="paste">📋 Paste</button>
        <button class="cm-tab"        data-tab="scroll">📜 Scroll</button>
      </div>

      <!-- ── PASTE TAB ── -->
      <div class="cm-pane active" id="cm-pane-paste">
        <div id="cm-status">
          <div id="cm-led"></div>
          <span id="cm-msg">No editor selected</span>
        </div>
        <div id="cm-btns">
          <button class="cm-btn" id="cm-btn-select">
            <span class="cm-icon">🎯</span><span>Paste Select</span>
          </button>
          <button class="cm-btn" id="cm-btn-paste">
            <span class="cm-icon">⚡</span><span>Paste Now</span>
            <span class="cm-kbd">Ctrl+V</span>
          </button>
          <div class="cm-sep"></div>
          <button class="cm-btn" id="cm-btn-clear">
            <span class="cm-icon">🗑️</span><span>Clear Selection</span>
          </button>
          <button class="cm-btn on" id="cm-btn-toggle">
            <span class="cm-icon">✨</span><span id="cm-tog-lbl">Disable</span>
          </button>
        </div>
      </div>

      <!-- ── SCROLL TAB ── -->
      <div class="cm-pane" id="cm-pane-scroll">
        <div id="cm-scroll-pane">

          <button id="cm-scroll-toggle">▶ Start Scrolling</button>
          <div id="cm-scroll-status" class="off">Stopped</div>

          <div class="cm-slider-row">
            <div class="cm-slider-label">Min pause (ms) <span id="v-minPause">1200</span></div>
            <input type="range" id="sl-minPause" min="300" max="5000" step="100" value="1200">
          </div>
          <div class="cm-slider-row">
            <div class="cm-slider-label">Max pause (ms) <span id="v-maxPause">2500</span></div>
            <input type="range" id="sl-maxPause" min="500" max="8000" step="100" value="2500">
          </div>
          <div class="cm-slider-row">
            <div class="cm-slider-label">Min scroll (px) <span id="v-minDist">120</span></div>
            <input type="range" id="sl-minDist" min="20" max="600" step="10" value="120">
          </div>
          <div class="cm-slider-row">
            <div class="cm-slider-label">Max scroll (px) <span id="v-maxDist">260</span></div>
            <input type="range" id="sl-maxDist" min="40" max="1000" step="10" value="260">
          </div>
          <div class="cm-slider-row">
            <div class="cm-slider-label">Smooth time (ms) <span id="v-smooth">650</span></div>
            <input type="range" id="sl-smooth" min="100" max="2000" step="50" value="650">
          </div>

        </div>
      </div>

    </div><!-- /cm-panel -->
  `;
  document.body.appendChild(root);

  const toast = document.createElement("div");
  toast.id = "cm-toast";
  document.body.appendChild(toast);

  /* ════════════════════════════════════════════════
     ELEMENT REFS
  ════════════════════════════════════════════════ */
  const orb    = root.querySelector("#cm-orb");
  const drag   = root.querySelector("#cm-drag");
  const panel  = root.querySelector("#cm-panel");
  const togBtn = root.querySelector("#cm-btn-toggle");
  const togLbl = root.querySelector("#cm-tog-lbl");

  /* ════════════════════════════════════════════════
     TABS
  ════════════════════════════════════════════════ */
  root.querySelectorAll(".cm-tab").forEach(tab => {
    tab.addEventListener("click", () => {
      root.querySelectorAll(".cm-tab").forEach(t => t.classList.remove("active"));
      root.querySelectorAll(".cm-pane").forEach(p => p.classList.remove("active"));
      tab.classList.add("active");
      root.querySelector(`#cm-pane-${tab.dataset.tab}`).classList.add("active");
    });
  });

  /* ════════════════════════════════════════════════
     VISIBILITY STATES
     "full"   → drag + panel visible
     "orb"    → only glowing purple ball
     "hidden" → completely invisible; toolbar icon restores
  ════════════════════════════════════════════════ */
  let uiState = "full";
  function show(state) {
    uiState = state;
    orb.style.display   = state === "orb"  ? "block" : "none";
    drag.style.display  = state === "full" ? "flex"  : "none";
    panel.style.display = state === "full" ? ""      : "none";
  }

  orb.addEventListener("click", () => show("full"));
  root.querySelector("#cm-ball-btn").addEventListener("click",   () => show("orb"));
  root.querySelector("#cm-vanish-btn").addEventListener("click", () => {
    show("hidden");
    notify("Hidden — click the extension icon to restore", "info");
  });

  /* toolbar icon click → toggle full / hidden */
  window.addEventListener("__cm_toggle", () => show(uiState === "full" ? "hidden" : "full"));

  /* ════════════════════════════════════════════════
     HELPERS
  ════════════════════════════════════════════════ */
  let toastTimer;
  function notify(msg, type = "info") {
    toast.textContent = msg;
    toast.className = `show ${type}`;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => (toast.className = type), 2600);
  }
  function setStatus(msg, ledClass = "") {
    root.querySelector("#cm-msg").textContent = msg;
    root.querySelector("#cm-led").className = ledClass;
  }

  /* ════════════════════════════════════════════════
     PASTE — your exact prototype logic
  ════════════════════════════════════════════════ */
  root.querySelector("#cm-btn-select").addEventListener("click", () => {
    const editors = document.querySelectorAll(".ace_editor");
    if (!editors.length) { notify("No ACE editors found on this page", "err"); return; }
    editors.forEach(el => (el.style.outline = "2px solid orange"));
    notify(`${editors.length} editor(s) found — click one`, "info");
    setStatus("Click an editor…", "ready");
    editors.forEach(el => {
      el.addEventListener("click", function handler() {
        selectedEditor = ace.edit(el.id);          // ← your exact line
        editors.forEach(ed => (ed.style.outline = ""));
        el.removeEventListener("click", handler);
        notify("Editor selected — Ctrl+V ready ✓", "ok");
        setStatus(`→ ${el.id || "editor"}`, "active");
      });
    });
  });

  root.querySelector("#cm-btn-paste").addEventListener("click", async () => {
    if (!enabled)        { notify("ClipMaster is disabled", "err"); return; }
    if (!selectedEditor) { notify("Select an editor first", "err"); return; }
    selectedEditor.focus();
    try {
      const text = await navigator.clipboard.readText();
      selectedEditor.insert(text);
      notify("Pasted! ✓", "ok");
    } catch {
      const fallback = prompt("Clipboard blocked. Paste here:");
      if (fallback) { selectedEditor.insert(fallback); notify("Pasted! ✓", "ok"); }
    }
  });

  root.querySelector("#cm-btn-clear").addEventListener("click", () => {
    selectedEditor = null;
    setStatus("No editor selected", "");
    notify("Selection cleared", "info");
  });

  togBtn.addEventListener("click", () => {
    enabled = !enabled;
    togBtn.classList.toggle("on", enabled);
    togLbl.textContent = enabled ? "Disable" : "Enable";
    if (!enabled) setStatus("Disabled", "off");
    else setStatus(selectedEditor ? "→ editor" : "No editor selected",
                   selectedEditor ? "active" : "");
    notify(enabled ? "Enabled ✓" : "Disabled", enabled ? "ok" : "info");
  });

  /* CTRL+V — your exact prototype handler */
  document.addEventListener("keydown", async (e) => {
    if (!enabled) return;
    if (!(e.ctrlKey || e.metaKey) || e.key.toLowerCase() !== "v") return;
    if (!selectedEditor) return;
    e.preventDefault();
    selectedEditor.focus();
    try {
      const text = await navigator.clipboard.readText();
      selectedEditor.insert(text);
      notify("Pasted! ✓", "ok");
    } catch {
      const fallback = prompt("Clipboard blocked. Paste here:");
      if (fallback) selectedEditor.insert(fallback);
    }
  }, true);

  /* ════════════════════════════════════════════════
     SCROLLER — your exact prototype logic
  ════════════════════════════════════════════════ */
  function rnd(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  function smoothScroll(container, start, end, duration) {
    const t0 = performance.now();
    function frame(now) {
      const p = Math.min((now - t0) / duration, 1);
      container.scrollTop = start + (end - start) * p * (2 - p); // ease-out
      if (p < 1) requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
  }

  function scrollNext() {
    const container = document.querySelector(".ng2-pdf-viewer-container");
    if (!container) {
      stopScroll();
      notify("Scroll target not found on this page", "err");
      return;
    }
    const dist = rnd(cfg.minDistance, cfg.maxDistance);
    const from = container.scrollTop;
    // reset to top when reaching bottom
    if (from + container.clientHeight >= container.scrollHeight - 5) {
      smoothScroll(container, from, 0, cfg.smoothTime);
    } else {
      smoothScroll(container, from, from + dist, cfg.smoothTime);
    }
    scrollTimeout = setTimeout(scrollNext, rnd(cfg.minPause, cfg.maxPause));
  }

  function startScroll() {
    if (scrollRunning) return;
    const container = document.querySelector(".ng2-pdf-viewer-container");
    if (!container) { notify("No .ng2-pdf-viewer-container found", "err"); return; }
    scrollRunning = true;
    scrollNext();
    root.querySelector("#cm-scroll-toggle").textContent  = "⏹ Stop Scrolling";
    root.querySelector("#cm-scroll-toggle").classList.add("running");
    root.querySelector("#cm-scroll-status").textContent  = "Running…";
    root.querySelector("#cm-scroll-status").className    = "on";
    notify("Scroller started ✓", "ok");
  }

  function stopScroll() {
    if (!scrollRunning) return;
    scrollRunning = false;
    clearTimeout(scrollTimeout);
    root.querySelector("#cm-scroll-toggle").textContent  = "▶ Start Scrolling";
    root.querySelector("#cm-scroll-toggle").classList.remove("running");
    root.querySelector("#cm-scroll-status").textContent  = "Stopped";
    root.querySelector("#cm-scroll-status").className    = "off";
    notify("Scroller stopped", "info");
  }

  root.querySelector("#cm-scroll-toggle").addEventListener("click", () => {
    scrollRunning ? stopScroll() : startScroll();
  });

  /* sliders — live update cfg */
  const sliders = [
    { id: "sl-minPause",  val: "v-minPause",  key: "minPause"    },
    { id: "sl-maxPause",  val: "v-maxPause",  key: "maxPause"    },
    { id: "sl-minDist",   val: "v-minDist",   key: "minDistance" },
    { id: "sl-maxDist",   val: "v-maxDist",   key: "maxDistance" },
    { id: "sl-smooth",    val: "v-smooth",    key: "smoothTime"  },
  ];
  sliders.forEach(({ id, val, key }) => {
    const el = root.querySelector(`#${id}`);
    const lbl = root.querySelector(`#${val}`);
    el.addEventListener("input", () => {
      cfg[key] = parseInt(el.value);
      lbl.textContent = el.value;
    });
  });

  /* ════════════════════════════════════════════════
     DRAG (works in full and orb states)
  ════════════════════════════════════════════════ */
  function makeDraggable(handle) {
    let on = false, ox = 0, oy = 0;
    handle.addEventListener("mousedown", e => {
      on = true;
      const r = root.getBoundingClientRect();
      ox = e.clientX - r.left; oy = e.clientY - r.top;
      e.preventDefault();
    });
    document.addEventListener("mousemove", e => {
      if (!on) return;
      let l = Math.max(0, Math.min(e.clientX - ox, innerWidth  - root.offsetWidth));
      let t = Math.max(0, Math.min(e.clientY - oy, innerHeight - root.offsetHeight));
      root.style.right = "auto"; root.style.bottom = "auto";
      root.style.left = l + "px"; root.style.top = t + "px";
    });
    document.addEventListener("mouseup", () => { on = false; });
  }
  makeDraggable(drag);
  makeDraggable(orb);

  console.log("✅ ClipMaster v5 active — @akarshmi github.com/akarshmi");
})();
