// Inject into the PAGE's JS world so window.ace is accessible
const s = document.createElement("script");
s.src = chrome.runtime.getURL("injector.js");
s.onload = () => s.remove();
(document.head || document.documentElement).appendChild(s);
