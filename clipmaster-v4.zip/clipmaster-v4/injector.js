(() => {
  /* ─── core state — unchanged from your working prototype ─── */
  let selectedEditor = null;
  let enabled = true;

  /* ══════════════════════════════════════════════════
     STYLES
  ══════════════════════════════════════════════════ */
  const css = document.createElement("style");
  css.textContent = `
    @import url('https://fonts.googleapis.com/css2?family=Fredoka+One&family=Nunito:wght@700;800;900&display=swap');

    /* ── root wrapper ── */
    #cm-root {
      position: fixed;
      top: 14px;
      right: 14px;
      z-index: 2147483647;
      display: flex;
      flex-direction: column;
      align-items: flex-end;
    }

    /* ════ DRAG STRIP ════ */
    #cm-drag {
      width: 100%;
      height: 18px;
      background: rgba(20, 4, 44, 0.72);   /* subtle — was solid #1a0533 */
      border-radius: 14px 14px 0 0;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: grab;
      gap: 5px;
      backdrop-filter: blur(8px);
    }
    #cm-drag:active { cursor: grabbing; }
    #cm-drag i {
      width: 4px; height: 4px;
      border-radius: 50%;
      background: #3a1055;
      display: block;
      transition: background .15s;
    }
    #cm-drag:hover i { background: #ff6aff; }

    /* ════ MAIN PANEL ════ */
    #cm-panel {
      width: 215px;
      /* subtle semi-transparent background instead of solid deep purple */
      background: rgba(14, 2, 30, 0.82);
      backdrop-filter: blur(14px);
      -webkit-backdrop-filter: blur(14px);
      border: 1.5px solid rgba(204, 0, 255, 0.45);
      border-top: none;
      border-radius: 0 0 14px 14px;
      overflow: hidden;
      box-shadow:
        0 0 0 3px rgba(204,0,255,.08),
        0 18px 48px rgba(0,0,0,.55);
      transition: opacity .25s, transform .25s;
    }

    /* ════ HEADER ════ */
    #cm-head {
      display: flex;
      align-items: center;
      gap: 7px;
      padding: 8px 10px 7px;
      /* subtle gradient — was harsh deep purple */
      background: rgba(28, 4, 56, 0.6);
      border-bottom: 1px solid rgba(90, 0, 130, 0.4);
    }

    /* title — smaller than before (was 16px) */
    #cm-title {
      font-family: 'Fredoka One', 'Comic Sans MS', cursive;
      font-size: 12px;               /* ← smaller */
      color: rgba(255, 106, 255, 0.7);
      letter-spacing: .03em;
      text-shadow: 0 0 8px rgba(255,106,255,.3);
      flex: none;                    /* don't stretch */
    }

    /* author — bigger, the star of the header */
    #cm-author {
      font-family: 'Fredoka One', 'Comic Sans MS', cursive;
      font-size: 15px;               /* ← bigger */
      font-weight: 400;
      color: #ff6aff;
      letter-spacing: .04em;
      text-decoration: none;
      text-shadow: 0 0 10px rgba(255,106,255,.55);
      flex: 1;
      transition: color .15s, text-shadow .15s;
      white-space: nowrap;
    }
    #cm-author:hover {
      color: #fff;
      text-shadow: 0 0 16px rgba(255,106,255,.9);
    }

    /* ── two control buttons in header ── */
    .cm-ctrl {
      width: 20px; height: 20px;
      border-radius: 50%;            /* circle / ball shape */
      border: none;
      cursor: pointer;
      display: flex; align-items: center; justify-content: center;
      font-size: 11px;
      transition: transform .15s, box-shadow .15s;
      flex-shrink: 0;
    }
    .cm-ctrl:hover { transform: scale(1.15); }
    .cm-ctrl:active { transform: scale(.92); }

    /* ball button — minimises to glowing ball */
    #cm-ball-btn {
      background: radial-gradient(circle at 35% 35%, #cc44ff, #7700cc);
      box-shadow: 0 0 8px rgba(204,0,255,.5);
      color: transparent;            /* no text — pure ball */
    }
    #cm-ball-btn:hover {
      box-shadow: 0 0 18px rgba(204,0,255,.8);
    }

    /* vanish button — fully hides, toolbar click restores */
    #cm-vanish-btn {
      background: radial-gradient(circle at 35% 35%, #ff4488, #aa0033);
      box-shadow: 0 0 8px rgba(255,60,120,.4);
      color: transparent;
    }
    #cm-vanish-btn:hover {
      box-shadow: 0 0 18px rgba(255,60,120,.75);
    }
    /* tiny dot inside each ball for visual depth */
    #cm-ball-btn::after,
    #cm-vanish-btn::after {
      content: '';
      width: 5px; height: 5px;
      border-radius: 50%;
      background: rgba(255,255,255,.3);
      position: absolute;
      top: 4px; left: 5px;
    }

    /* ════ STATUS BAR ════ */
    #cm-status {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 5px 12px;
      background: rgba(8, 0, 20, 0.5);
      border-bottom: 1px solid rgba(30, 0, 64, 0.6);
    }
    #cm-led {
      width: 7px; height: 7px;
      border-radius: 50%;
      flex-shrink: 0;
      background: #2a0050;
      transition: background .3s;
    }
    #cm-led.ready  { background: #cc00ff; animation: cm-glow  1.8s infinite; }
    #cm-led.active { background: #00ffaa; animation: cm-glow2 1.8s infinite; }
    #cm-led.off    { background: #ff3355; box-shadow: 0 0 6px #ff3355; }
    @keyframes cm-glow  {
      0%,100% { box-shadow: 0 0 4px #cc00ff; }
      50%      { box-shadow: 0 0 14px #cc00ff; }
    }
    @keyframes cm-glow2 {
      0%,100% { box-shadow: 0 0 4px #00ffaa; }
      50%      { box-shadow: 0 0 14px #00ffaa; }
    }
    #cm-msg {
      font-family: 'Nunito', 'Comic Sans MS', cursive;
      font-size: 10px;
      font-weight: 700;
      color: #5a2a7a;
      flex: 1;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    /* ════ BUTTONS ════ */
    #cm-btns {
      padding: 6px 6px 7px;
      display: flex;
      flex-direction: column;
      gap: 3px;
      background: rgba(10, 0, 26, 0.5);
    }
    .cm-btn {
      display: flex;
      align-items: center;
      gap: 9px;
      width: 100%;
      padding: 7px 10px;
      background: rgba(24, 0, 48, 0.55);
      border: 1.5px solid rgba(46, 0, 85, 0.7);
      border-radius: 9px;
      cursor: pointer;
      font-family: 'Nunito', 'Comic Sans MS', cursive;
      font-size: 12px;
      font-weight: 800;
      color: #7744aa;
      text-align: left;
      transition: all .13s;
    }
    .cm-btn:hover {
      transform: translateX(3px) scale(1.01);
      border-color: rgba(204,0,255,.7);
      color: #ff9aff;
      background: rgba(34, 0, 68, 0.7);
      box-shadow: 0 0 10px rgba(204,0,255,.18);
    }
    .cm-btn:active { transform: scale(.97); }
    .cm-icon {
      width: 22px; height: 22px;
      border-radius: 6px;
      display: flex; align-items: center; justify-content: center;
      font-size: 14px; flex-shrink: 0;
    }
    #cm-btn-select:hover { border-color: rgba(255,215,0,.7); color: #ffd700; }
    #cm-btn-paste:hover  { border-color: rgba(0,255,200,.7); color: #00ffcc; }
    #cm-btn-clear:hover  { border-color: rgba(255,60,120,.7); color: #ff3c78; }
    #cm-btn-toggle:hover { border-color: rgba(255,106,255,.7); color: #ff6aff; }

    .cm-kbd {
      margin-left: auto;
      background: rgba(10,0,24,.6);
      border: 1px solid rgba(42,0,80,.8);
      border-radius: 5px;
      padding: 1px 6px;
      font-family: 'Nunito', cursive;
      font-size: 9px;
      font-weight: 900;
      color: #3a1060;
    }
    .cm-sep {
      height: 1px;
      background: linear-gradient(90deg, transparent, rgba(60,0,100,.6), transparent);
      margin: 2px 4px;
    }

    /* ════ TOAST ════ */
    #cm-toast {
      position: fixed;
      bottom: 16px; right: 16px;
      z-index: 2147483647;
      font-family: 'Nunito', 'Comic Sans MS', cursive;
      font-size: 13px;
      font-weight: 800;
      padding: 9px 16px;
      border-radius: 12px;
      pointer-events: none;
      opacity: 0;
      transform: translateY(10px) scale(.96);
      transition: opacity .18s, transform .18s;
      max-width: calc(100vw - 32px);
    }
    #cm-toast.show { opacity: 1; transform: translateY(0) scale(1); }
    #cm-toast.ok   { background:#001a10; border:2px solid #00ffaa; color:#00ffaa; box-shadow:0 0 20px rgba(0,255,170,.3); }
    #cm-toast.err  { background:#1a0008; border:2px solid #ff3c78; color:#ff3c78; box-shadow:0 0 20px rgba(255,60,120,.3); }
    #cm-toast.info { background:rgba(10,0,26,.9); border:2px solid rgba(204,0,255,.6); color:#dd88ff; box-shadow:0 0 16px rgba(204,0,255,.2); }

    /* ════ BALL STATE (minimised to glowing orb) ════ */
    #cm-ball {
      display: none;
      width: 38px; height: 38px;
      border-radius: 50%;
      background: radial-gradient(circle at 35% 30%, #dd55ff, #6600bb);
      box-shadow:
        0 0 12px rgba(204,0,255,.6),
        0 0 30px rgba(204,0,255,.25),
        inset 0 2px 4px rgba(255,255,255,.2);
      cursor: pointer;
      transition: box-shadow .2s, transform .15s;
      position: relative;
    }
    #cm-ball:hover {
      transform: scale(1.12);
      box-shadow: 0 0 22px rgba(204,0,255,.9), 0 0 44px rgba(204,0,255,.35);
    }
    #cm-ball::before {
      /* shine spot */
      content: '';
      position: absolute;
      width: 10px; height: 10px;
      background: rgba(255,255,255,.35);
      border-radius: 50%;
      top: 6px; left: 8px;
    }
    #cm-ball::after {
      /* tiny pulsing ring */
      content: '';
      position: absolute;
      inset: -5px;
      border-radius: 50%;
      border: 2px solid rgba(204,0,255,.3);
      animation: cm-ring 2s infinite;
    }
    @keyframes cm-ring {
      0%   { transform: scale(1);   opacity: .6; }
      100% { transform: scale(1.35); opacity: 0; }
    }
  `;
  document.head.appendChild(css);

  /* ══════════════════════════════════════════════════
     DOM
  ══════════════════════════════════════════════════ */
  const root = document.createElement("div");
  root.id = "cm-root";
  root.innerHTML = `
    <!-- Glowing ball (minimised state) -->
    <div id="cm-ball" title="Click to expand ClipMaster"></div>

    <!-- Drag handle -->
    <div id="cm-drag">
      <i></i><i></i><i></i><i></i><i></i><i></i>
    </div>

    <!-- Main panel -->
    <div id="cm-panel">
      <div id="cm-head">
        <span id="cm-title">📋</span>
        <a id="cm-author" href="https://github.com/akarshmi"
           target="_blank" rel="noopener">@akarshmi</a>

        <!-- ● ball button: shrinks widget to glowing orb -->
        <button id="cm-ball-btn" class="cm-ctrl"
                title="Minimise to ball"></button>

        <!-- ● vanish button: fully hides; click extension icon to restore -->
        <button id="cm-vanish-btn" class="cm-ctrl"
                title="Vanish (click extension icon to restore)"></button>
      </div>

      <div id="cm-status">
        <div id="cm-led"></div>
        <span id="cm-msg">No editor selected</span>
      </div>

      <div id="cm-btns">
        <button class="cm-btn" id="cm-btn-select">
          <span class="cm-icon">🎯</span><span>Paste Select</span>
        </button>
        <button class="cm-btn" id="cm-btn-paste">
          <span class="cm-icon">⚡</span><span>Paste Now</span>
          <span class="cm-kbd">Ctrl+V</span>
        </button>
        <div class="cm-sep"></div>
        <button class="cm-btn" id="cm-btn-clear">
          <span class="cm-icon">🗑️</span><span>Clear Selection</span>
        </button>
        <button class="cm-btn on" id="cm-btn-toggle">
          <span class="cm-icon">✨</span><span id="cm-tog-lbl">Disable</span>
        </button>
      </div>
    </div>
  `;
  document.body.appendChild(root);

  const toast = document.createElement("div");
  toast.id = "cm-toast";
  document.body.appendChild(toast);

  /* ── shortcuts ── */
  const ball    = root.querySelector("#cm-ball");
  const drag    = root.querySelector("#cm-drag");
  const panel   = root.querySelector("#cm-panel");
  const togBtn  = root.querySelector("#cm-btn-toggle");
  const togLbl  = root.querySelector("#cm-tog-lbl");

  /* ══════════════════════════════════════════════════
     THREE VISIBILITY STATES
       "full"   → drag + panel visible, ball hidden
       "ball"   → only glowing ball visible
       "hidden" → everything hidden (toolbar icon restores)
  ══════════════════════════════════════════════════ */
  let uiState = "full";

  function show(state) {
    uiState = state;
    ball.style.display  = state === "ball"   ? "block" : "none";
    drag.style.display  = state === "full"   ? "flex"  : "none";
    panel.style.display = state === "full"   ? ""      : "none";
    // root itself stays in DOM in all states (needed for drag position memory)
  }

  /* purple ball → expand back to full */
  ball.addEventListener("click", () => show("full"));

  /* ball button (purple circle in header) → shrink to ball */
  root.querySelector("#cm-ball-btn").addEventListener("click", () => show("ball"));

  /* vanish button (pink circle in header) → fully hidden */
  root.querySelector("#cm-vanish-btn").addEventListener("click", () => {
    show("hidden");
    notify("Widget hidden — click the extension icon to restore", "info");
  });

  /* ── toolbar icon click → always restore to full ── */
  window.addEventListener("__cm_toggle", () => {
    show(uiState === "full" ? "hidden" : "full");
  });

  /* ══════════════════════════════════════════════════
     HELPERS
  ══════════════════════════════════════════════════ */
  let toastTimer;
  function notify(msg, type = "info") {
    toast.textContent = msg;
    toast.className = `show ${type}`;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => (toast.className = type), 2600);
  }
  function setStatus(msg, ledClass = "") {
    root.querySelector("#cm-msg").textContent = msg;
    root.querySelector("#cm-led").className = ledClass;
  }

  /* ══════════════════════════════════════════════════
     SELECT MODE — your exact prototype logic
  ══════════════════════════════════════════════════ */
  root.querySelector("#cm-btn-select").addEventListener("click", () => {
    const editors = document.querySelectorAll(".ace_editor");
    if (!editors.length) { notify("No ACE editors found on this page", "err"); return; }

    editors.forEach((el) => (el.style.outline = "2px solid orange"));
    notify(`${editors.length} editor(s) found — click one`, "info");
    setStatus("Click an editor…", "ready");

    editors.forEach((el) => {
      el.addEventListener("click", function handler() {
        selectedEditor = ace.edit(el.id);          // ← your exact line
        editors.forEach((ed) => (ed.style.outline = ""));
        el.removeEventListener("click", handler);
        notify("Editor selected — Ctrl+V ready ✓", "ok");
        setStatus(`→ ${el.id || "editor"}`, "active");
      });
    });
  });

  /* ══════════════════════════════════════════════════
     PASTE NOW
  ══════════════════════════════════════════════════ */
  root.querySelector("#cm-btn-paste").addEventListener("click", async () => {
    if (!enabled)        { notify("ClipMaster is disabled", "err"); return; }
    if (!selectedEditor) { notify("Select an editor first", "err"); return; }
    selectedEditor.focus();
    try {
      const text = await navigator.clipboard.readText();
      selectedEditor.insert(text);
      notify("Pasted! ✓", "ok");
    } catch {
      const fallback = prompt("Clipboard blocked. Paste here:");
      if (fallback) { selectedEditor.insert(fallback); notify("Pasted! ✓", "ok"); }
    }
  });

  /* ══════════════════════════════════════════════════
     CLEAR
  ══════════════════════════════════════════════════ */
  root.querySelector("#cm-btn-clear").addEventListener("click", () => {
    selectedEditor = null;
    setStatus("No editor selected", "");
    notify("Selection cleared", "info");
  });

  /* ══════════════════════════════════════════════════
     ENABLE / DISABLE
  ══════════════════════════════════════════════════ */
  togBtn.addEventListener("click", () => {
    enabled = !enabled;
    togBtn.classList.toggle("on", enabled);
    togLbl.textContent = enabled ? "Disable" : "Enable";
    if (!enabled) setStatus("Disabled", "off");
    else setStatus(selectedEditor ? "→ editor" : "No editor selected",
                   selectedEditor ? "active" : "");
    notify(enabled ? "Enabled ✓" : "Disabled", enabled ? "ok" : "info");
  });

  /* ══════════════════════════════════════════════════
     DRAG — works in full and ball states
  ══════════════════════════════════════════════════ */
  function makeDraggable(handle) {
    let on = false, ox = 0, oy = 0;
    handle.addEventListener("mousedown", (e) => {
      on = true;
      const r = root.getBoundingClientRect();
      ox = e.clientX - r.left; oy = e.clientY - r.top;
      e.preventDefault();
    });
    document.addEventListener("mousemove", (e) => {
      if (!on) return;
      let l = Math.max(0, Math.min(e.clientX - ox, innerWidth  - root.offsetWidth));
      let t = Math.max(0, Math.min(e.clientY - oy, innerHeight - root.offsetHeight));
      root.style.right = "auto"; root.style.bottom = "auto";
      root.style.left = l + "px"; root.style.top = t + "px";
    });
    document.addEventListener("mouseup", () => { on = false; });
  }
  makeDraggable(drag);
  makeDraggable(ball);  // ball is also draggable

  /* ══════════════════════════════════════════════════
     CTRL+V — your exact prototype handler
  ══════════════════════════════════════════════════ */
  document.addEventListener("keydown", async (e) => {
    if (!enabled) return;
    if (!(e.ctrlKey || e.metaKey) || e.key.toLowerCase() !== "v") return;
    if (!selectedEditor) return;
    e.preventDefault();
    selectedEditor.focus();
    try {
      const text = await navigator.clipboard.readText();
      selectedEditor.insert(text);
      notify("Pasted! ✓", "ok");
    } catch {
      const fallback = prompt("Clipboard blocked. Paste here:");
      if (fallback) selectedEditor.insert(fallback);
    }
  }, true);

  console.log("✅ ClipMaster v4 active — @akarshmi github.com/akarshmi");
})();
