// When the user clicks the extension icon in the toolbar,
// send a message to the active tab's content script to toggle the widget.
chrome.action.onClicked.addListener((tab) => {
  chrome.tabs.sendMessage(tab.id, { type: "CM_TOGGLE_WIDGET" });
});
