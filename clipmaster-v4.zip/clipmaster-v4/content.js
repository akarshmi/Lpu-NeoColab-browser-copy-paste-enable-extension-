// 1. Inject your script into the page world (where window.ace lives)
const s = document.createElement("script");
s.src = chrome.runtime.getURL("injector.js");
s.onload = () => s.remove();
(document.head || document.documentElement).appendChild(s);

// 2. Listen for toolbar-icon clicks relayed from background.js
//    and forward them into the page world via a CustomEvent
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "CM_TOGGLE_WIDGET") {
    window.dispatchEvent(new CustomEvent("__cm_toggle"));
  }
});
